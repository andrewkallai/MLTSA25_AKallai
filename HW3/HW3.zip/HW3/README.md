# Homework 3

continuing on with the stock market (if anyone of you gets rich I expect a cut!) use ARMA and ARIMA models to forecast stock price.
Follow the notebook instructions ARIMA_instructions.ipynb

Perform an autoregressive model analysis of Uber rides data with Facebook Prophet, notebook berprophet_instructions
NOTE: there is a lot of optional stuff there! Prophet allows you to include exogenous variables in addition to autoregressive elements! 


# Reading
Sorry ARIMA, but I’m Going Bayesian

https://multithreaded.stitchfix.com/blog/2016/04/21/forget-arima/


